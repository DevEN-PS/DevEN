# DevEN Detached Update Replacer Script (Python Version Smart & Pip Install Aware)
import sys
import os
import time
import shutil
import subprocess

def main():
    pid = int(sys.argv[1]) if len(sys.argv) > 1 else 0
    source_dir = sys.argv[2] if len(sys.argv) > 2 else ""
    target_dir = sys.argv[3] if len(sys.argv) > 3 else ""

    print(f"Update replacer started. Waiting for PID {pid} to terminate...")
    time.sleep(1.8)

    if not source_dir or not target_dir or not os.path.exists(source_dir):
        print("Invalid source or target directory.")
        return

    # Handle single subfolder wrapper if present
    subitems = [os.path.join(source_dir, d) for d in os.listdir(source_dir)]
    if len(subitems) == 1 and os.path.isdir(subitems[0]):
        source_dir = subitems[0]

    # Detect active Python version tag (e.g. Py313, Py312)
    py_tag = f"Py{sys.version_info.major}{sys.version_info.minor}"
    
    # Search for matching standalone folder (e.g., DevEN_V2_Py313)
    matching_folder = None
    for item in os.listdir(source_dir):
        item_path = os.path.join(source_dir, item)
        if os.path.isdir(item_path) and py_tag in item:
            matching_folder = item_path
            break
            
    if not matching_folder:
        # Fallback to any DevEN_V*_Py* folder
        for item in os.listdir(source_dir):
            item_path = os.path.join(source_dir, item)
            if os.path.isdir(item_path) and "Py" in item:
                matching_folder = item_path
                break

    install_src = matching_folder if matching_folder else source_dir
    print(f"Active Python version: {sys.version.split()[0]} (Tag: {py_tag})")
    print(f"Installing from folder: {install_src} -> Target: {target_dir}")

    # 1. Copy all compiled bytecode, assets, Example, icons, Map, engines, utils into target_dir
    for root, dirs, files in os.walk(install_src):
        rel_path = os.path.relpath(root, install_src)
        dest_root = os.path.join(target_dir, rel_path) if rel_path != '.' else target_dir
        os.makedirs(dest_root, exist_ok=True)
        
        for f in files:
            src_file = os.path.join(root, f)
            dest_file = os.path.join(dest_root, f)
            if f.endswith('.pyc'):
                old_py = os.path.join(dest_root, f[:-1]) # remove 'c'
                if os.path.exists(old_py):
                    try: os.remove(old_py)
                    except Exception: pass
            try:
                shutil.copy2(src_file, dest_file)
                print(f"  [+] Installed: {f}")
            except Exception as e:
                print(f"  [-] Failed: {f}: {e}")

    # 2. Cleanup temp extract folder
    try:
        shutil.rmtree(source_dir, ignore_errors=True)
    except Exception:
        pass

    # 3. Locate target environment Python executable
    v1 = os.path.join(target_dir, "venv", "Scripts", "python.exe")
    v2 = os.path.join(os.path.dirname(target_dir), "venv", "Scripts", "python.exe")
    venv_py = v1 if os.path.exists(v1) else (v2 if os.path.exists(v2) else sys.executable)

    # 4. Install/Upgrade requirements.txt BEFORE restarting
    req_file = os.path.join(target_dir, "requirements.txt")
    if os.path.exists(req_file):
        print(f"📦 Installing dependencies from {req_file} using {venv_py}...")
        try:
            cmd = [venv_py, "-m", "pip", "install", "-r", req_file]
            res = subprocess.run(cmd, capture_output=True, text=True, creationflags=0x08000000 if sys.platform == 'win32' else 0)
            if res.returncode == 0:
                print("✅ All requirements installed successfully!")
            else:
                print(f"⚠️ Pip install output note: {res.stderr[:300]}")
        except Exception as ex:
            print(f"⚠️ Error executing pip install: {ex}")

    # 5. Relaunch DevEN after requirements are installed
    print("Relaunching DevEN...")
    entry_script = "app.py" if os.path.exists(os.path.join(target_dir, "app.py")) else "app.pyc"
    app_path = os.path.join(target_dir, entry_script)
    
    subprocess.Popen([venv_py, app_path], creationflags=0x00000008)

if __name__ == '__main__':
    main()
