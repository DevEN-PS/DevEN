@echo off
if "%~1"=="" (
    cmd /k "%~f0" RUN
    exit /b
)
setlocal enabledelayedexpansion
chcp 65001 >nul 2>&1
title Python Auto Setup for Windows

echo.
echo ============================================================
echo   DevEN Multi-Version Auto Setup for Windows
echo ============================================================
echo.
echo [0/6] Available Release Version Folders in Package:
for /d %%v in (DevEN_V*) do (
    echo       - %%v
)
echo.
echo.

set "VENV_NAME=venv"
set "REQ_FILE=requirements.txt"
set "RUN_BAT=run.bat"
set "VER_1_MM=3.13"
set "VER_1_FULL=3.13.0"
set "VER_2_MM=3.12"
set "VER_2_FULL=3.12.0"
set "VER_3_MM=3.11"
set "VER_3_FULL=3.11.0"

echo [1/6] Scanning for Python installations...
echo.

set "FOUND_313="
set "FOUND_312="
set "FOUND_311="

call :check_python "313" "3.13"
call :check_python "312" "3.12"
call :check_python "311" "3.11"

set /a FOUND_COUNT=0
if defined FOUND_313 set /a FOUND_COUNT+=1
if defined FOUND_312 set /a FOUND_COUNT+=1
if defined FOUND_311 set /a FOUND_COUNT+=1

echo.
echo     Scan complete. Found !FOUND_COUNT! compatible Python version(s).
echo.

if "!FOUND_COUNT!"=="0" goto :none_found
if "!FOUND_COUNT!"=="1" goto :one_found
goto :multiple_found

:one_found
if defined FOUND_313 (
    set "PYTHON_EXE=!FOUND_313!"
    set "PYTHON_VER=3.13"
    echo     [OK] Using Python 3.13: !FOUND_313!
)
if defined FOUND_312 (
    set "PYTHON_EXE=!FOUND_312!"
    set "PYTHON_VER=3.12"
    echo     [OK] Using Python 3.12: !FOUND_312!
)
if defined FOUND_311 (
    set "PYTHON_EXE=!FOUND_311!"
    set "PYTHON_VER=3.11"
    echo     [OK] Using Python 3.11: !FOUND_311!
)
echo.
set /p "CONFIRM=     Use this version? (Y/n): "
if /i not "!CONFIRM!"=="n" goto :skip_install
goto :ask_which_version

:multiple_found
echo     Multiple Python versions detected!
echo.
echo     Which version would you like to use?
echo.
set "MENU_NUM=0"
if defined FOUND_313 (
    set /a MENU_NUM+=1
    echo       !MENU_NUM!. Python 3.13  [!FOUND_313!]
    set "MENU_1=313"
)
if defined FOUND_312 (
    set /a MENU_NUM+=1
    echo       !MENU_NUM!. Python 3.12  [!FOUND_312!]
    set "MENU_2=312"
)
if defined FOUND_311 (
    set /a MENU_NUM+=1
    echo       !MENU_NUM!. Python 3.11  [!FOUND_311!]
    set "MENU_3=311"
)
set /a MENU_NUM+=1
echo       !MENU_NUM!. Install a different version...
set "MENU_INSTALL=!MENU_NUM!"
echo.
set /p "PICK=     Enter choice (1-!MENU_NUM!): "

set "VALID=0"
if "!PICK!"=="1" if defined MENU_1 (
    set "CHOSEN_ID=!MENU_1!"
    set "VALID=1"
)
if "!PICK!"=="2" if defined MENU_2 (
    set "CHOSEN_ID=!MENU_2!"
    set "VALID=1"
)
if "!PICK!"=="3" if defined MENU_3 (
    set "CHOSEN_ID=!MENU_3!"
    set "VALID=1"
)
if "!PICK!"=="!MENU_INSTALL!" goto :ask_which_version
if "!VALID!"=="0" (
    echo.
    echo     [ERROR] Invalid choice.
    echo.
    pause
    exit /b 1
)
if "!CHOSEN_ID!"=="313" (
    set "PYTHON_EXE=!FOUND_313!"
    set "PYTHON_VER=3.13"
    echo.
    echo     [OK] Selected Python 3.13: !FOUND_313!
)
if "!CHOSEN_ID!"=="312" (
    set "PYTHON_EXE=!FOUND_312!"
    set "PYTHON_VER=3.12"
    echo.
    echo     [OK] Selected Python 3.12: !FOUND_312!
)
if "!CHOSEN_ID!"=="311" (
    set "PYTHON_EXE=!FOUND_311!"
    set "PYTHON_VER=3.11"
    echo.
    echo     [OK] Selected Python 3.11: !FOUND_311!
)
goto :skip_install

:none_found
echo     [!] No compatible Python found (3.11 / 3.12 / 3.13).
echo.

:ask_which_version
echo.
echo     Which Python version would you like to install?
echo.
echo       1. Python 3.13 (Latest)
echo       2. Python 3.12 (Stable)
echo       3. Python 3.11 (Most compatible)
echo       4. Cancel
echo.
set /p "VER_CHOICE=     Enter choice (1-4): "
if "!VER_CHOICE!"=="1" (
    set "INSTALL_MM=3.13"
    set "INSTALL_FULL=3.13.0"
    set "INSTALL_DIR=Python313"
    set "PYTHON_VER=3.13"
) else if "!VER_CHOICE!"=="2" (
    set "INSTALL_MM=3.12"
    set "INSTALL_FULL=3.12.0"
    set "INSTALL_DIR=Python312"
    set "PYTHON_VER=3.12"
) else if "!VER_CHOICE!"=="3" (
    set "INSTALL_MM=3.11"
    set "INSTALL_FULL=3.11.0"
    set "INSTALL_DIR=Python311"
    set "PYTHON_VER=3.11"
) else (
    echo.
    echo     Cancelled.
    pause
    exit /b 0
)
echo.
echo     You chose Python !INSTALL_MM!
echo.
set /p "INSTALL_CONFIRM=     Install Python !INSTALL_MM! now? (Y/n): "
if /i "!INSTALL_CONFIRM!"=="n" (
    echo     Cancelled.
    pause
    exit /b 0
)

echo.
echo [2/6] Downloading Python !INSTALL_FULL!...
set "ARCH=64bit"
if "%PROCESSOR_ARCHITECTURE%"=="ARM64" set "ARCH=arm64"
if "%PROCESSOR_ARCHITECTURE%"=="x86" set "ARCH=32bit"
set "BASE_URL=https://www.python.org/ftp/python/!INSTALL_FULL!"
set "DOWNLOAD_URL=!BASE_URL!/python-!INSTALL_FULL!-amd64.exe"
if "!ARCH!"=="arm64" set "DOWNLOAD_URL=!BASE_URL!/python-!INSTALL_FULL!-arm64.exe"
if "!ARCH!"=="32bit" set "DOWNLOAD_URL=!BASE_URL!/python-!INSTALL_FULL!.exe"
echo     Architecture: !ARCH!
echo     URL: !DOWNLOAD_URL!
echo.
echo     Downloading... (this may take a minute)
set "TEMP_DIR=%TEMP%\python_setup_%RANDOM%"
mkdir "!TEMP_DIR!" 2>nul
set "INSTALLER_PATH=!TEMP_DIR!\python_installer.exe"
powershell -NoProfile -Command "$ProgressPreference = 'SilentlyContinue'; try { Invoke-WebRequest -Uri \"!DOWNLOAD_URL!\" -OutFile \"!INSTALLER_PATH!\" -UseBasicParsing; if (Test-Path \"!INSTALLER_PATH!\") { Write-Host '     Download complete!' } else { Write-Host '     Download failed!' } } catch { Write-Host ('Download error: ' + $_.Exception.Message) }"
if not exist "!INSTALLER_PATH!" (
    echo.
    echo     [ERROR] Download failed!
    echo     Try downloading manually from: https://www.python.org/downloads/
    echo.
    rd /s /q "!TEMP_DIR!" 2>nul
    goto :end_error
)

echo.
echo [3/6] Installing Python !INSTALL_FULL!...
echo     This may take a few minutes. Please wait...
echo.
set "TARGET_DIR=C:\!INSTALL_DIR!"
"!INSTALLER_PATH!" /quiet InstallAllUsers=1 PrependPath=1 Include_test=0 Include_doc=0 Include_launcher=0 InstallLauncherAllUsers=0 TargetDir="!TARGET_DIR!"
if %errorlevel% neq 0 (
    echo     [WARN] Standard install failed, trying with elevation...
    powershell -NoProfile -Command "Start-Process '!INSTALLER_PATH!' -ArgumentList '/quiet','InstallAllUsers=1','PrependPath=1','Include_test=0','Include_doc=0','Include_launcher=0','InstallLauncherAllUsers=0','TargetDir=!TARGET_DIR!' -Verb RunAs -Wait"
)
rd /s /q "!TEMP_DIR!" 2>nul
echo     Waiting for system to register Python...
timeout /t 5 /nobreak >nul
set "PYTHON_EXE=!TARGET_DIR!\python.exe"
if not exist "!PYTHON_EXE!" (
    echo     [ERROR] Python installed but not found at: !PYTHON_EXE!
    goto :end_error
)
echo     [OK] Python !INSTALL_FULL! installed successfully!
echo     Location: !PYTHON_EXE!

:skip_install
set "VER_NODOT=!PYTHON_VER:.=!"
set "TARGET_VER_DIR="
for /d %%d in (*_Py!VER_NODOT! DevEN_V*_Py!VER_NODOT!) do (
    if exist "%%d" (
        set "TARGET_VER_DIR=%%d"
    )
)
if defined TARGET_VER_DIR (
    call :do_cd "!TARGET_VER_DIR!"
)

echo.
echo [4/6] Creating virtual environment inside: %CD%\...
if exist "%VENV_NAME%" (
    echo     Virtual environment '%VENV_NAME%' already exists.
    set /p "RECREATE=     Remove and recreate? (y/n): "
    if /i "!RECREATE!"=="y" (
        echo     Removing old environment...
        rd /s /q "%VENV_NAME%" 2>nul
        echo     Removed.
    ) else (
        echo     Keeping existing environment.
        goto :install_reqs
    )
)
echo     Using Python: !PYTHON_EXE!
"!PYTHON_EXE!" --version >nul 2>&1
if %errorlevel% neq 0 (
    echo     [ERROR] Python executable is not working: !PYTHON_EXE!
    goto :end_error
)
"!PYTHON_EXE!" -m venv %VENV_NAME%
if %errorlevel% neq 0 (
    echo     [ERROR] Failed to create virtual environment!
    echo     Try running this script as Administrator.
    goto :end_error
)
echo     [OK] Virtual environment created: %VENV_NAME%\

:install_reqs
echo.
echo [5/6] Installing requirements...
set "VENV_PYTHON=%VENV_NAME%\Scripts\python.exe"
if not exist "%VENV_PYTHON%" (
    echo     [ERROR] Virtual environment Python not found!
    goto :end_error
)
echo     Environment Python:
"%VENV_PYTHON%" --version
echo     Upgrading pip...
"%VENV_PYTHON%" -m pip install --upgrade pip --quiet 2>nul
echo     [OK] pip ready.
if exist "%REQ_FILE%" (
    for %%f in ("%REQ_FILE%") do if %%~zf==0 (
        echo     %REQ_FILE% is empty, skipping.
        goto :create_run_bat
    )
    echo     Installing packages from %REQ_FILE%...
    echo.
    "%VENV_PYTHON%" -m pip install -r "%REQ_FILE%"
    if %errorlevel% neq 0 (
        echo.
        echo     [WARN] Some packages may have failed.
        echo     Try manually:
        echo       %VENV_NAME%\Scripts\activate
        echo       pip install -r %REQ_FILE%
    ) else (
        echo.
        echo     [OK] All requirements installed!
    )
) else (
    echo     [INFO] %REQ_FILE% not found. Creating empty file.
    echo # Add your Python packages here > "%REQ_FILE%"
    echo     Created %REQ_FILE%.
)

:create_run_bat
echo.
echo [6/6] Creating run.bat and Desktop shortcut...
set "SCRIPT_DIR=%~dp0"
if "!SCRIPT_DIR:~-1!"=="\" set "SCRIPT_DIR=!SCRIPT_DIR:~0,-1!"
> "%RUN_BAT%" echo @echo off
>> "%RUN_BAT%" echo setlocal
>> "%RUN_BAT%" echo chcp 65001 ^>nul 2^>^&1
>> "%RUN_BAT%" echo title App Runner
>> "%RUN_BAT%" echo cd /d "%%~dp0"
>> "%RUN_BAT%" echo.
>> "%RUN_BAT%" echo if not exist "%VENV_NAME%\Scripts\activate" ^(
>> "%RUN_BAT%" echo     echo [ERROR] Virtual environment not found!
>> "%RUN_BAT%" echo     echo Please run setup.bat first.
>> "%RUN_BAT%" echo     pause
>> "%RUN_BAT%" echo     exit /b 1
>> "%RUN_BAT%" echo ^)
>> "%RUN_BAT%" echo.
>> "%RUN_BAT%" echo call "%VENV_NAME%\Scripts\activate"
>> "%RUN_BAT%" echo.
>> "%RUN_BAT%" echo echo.
>> "%RUN_BAT%" echo echo ============================================================
>> "%RUN_BAT%" echo echo   Starting Application...
>> "%RUN_BAT%" echo echo ============================================================
>> "%RUN_BAT%" echo echo.
>> "%RUN_BAT%" echo.
>> "%RUN_BAT%" echo if exist "app.pyC" ^(
>> "%RUN_BAT%" echo     python app.pyC
>> "%RUN_BAT%" echo     echo.
>> "%RUN_BAT%" echo     echo   Application closed.
>> "%RUN_BAT%" echo ^) else ^(
>> "%RUN_BAT%" echo     echo.
>> "%RUN_BAT%" echo     echo [ERROR] app.pyC not found!
>> "%RUN_BAT%" echo     echo Please place app.pyC next to this file.
>> "%RUN_BAT%" echo     echo.
>> "%RUN_BAT%" echo ^)
>> "%RUN_BAT%" echo.
>> "%RUN_BAT%" echo pause
echo     [OK] Created %RUN_BAT%

set "ICON_PATH=!SCRIPT_DIR!\icon.ico"
set "DESKTOP_PATH="
for /f "tokens=2*" %%a in ('reg query "HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\User Shell Folders" /v Desktop 2^>nul') do (
    set "DESKTOP_PATH=%%b"
)
if not defined DESKTOP_PATH set "DESKTOP_PATH=%USERPROFILE%\Desktop"
set "SHORTCUT_PATH=!DESKTOP_PATH!\DevEN.lnk"
set "TARGET_PATH=!SCRIPT_DIR!\%RUN_BAT%"
set "WORK_DIR=!SCRIPT_DIR!"
echo     Creating Desktop shortcut...
powershell -NoProfile -Command "$ws = New-Object -ComObject WScript.Shell; $sc = $ws.CreateShortcut('!SHORTCUT_PATH!'); $sc.TargetPath = '!TARGET_PATH!'; $sc.WorkingDirectory = '!WORK_DIR!'; $sc.Description = 'Launch Application'; if (Test-Path '!ICON_PATH!') { $sc.IconLocation = '!ICON_PATH!,0'; Write-Host '     [OK] Icon applied' } else { Write-Host '     [WARN] icon.ico not found' }; $sc.Save()"
if exist "!SHORTCUT_PATH!" (
    echo     [OK] Shortcut created: Desktop\DevEN.lnk
) else (
    echo     [WARN] Shortcut creation may have failed.
    echo     Manually create shortcut to: !TARGET_PATH!
)

echo.
echo ============================================================
echo   Setup Complete!
echo ============================================================
echo.
echo   Python Version:       !PYTHON_VER!
echo   Virtual Environment:  %VENV_NAME%\
echo   Python:               %VENV_NAME%\Scripts\python.exe
echo   pip:                  %VENV_NAME%\Scripts\pip.exe
echo   Run App:              Double-click %RUN_BAT%
echo   Desktop Shortcut:     DevEN.lnk
echo.
echo ============================================================
echo.
pause
exit /b 0

REM ============================================
REM  CHECK PYTHON - FLAT STRUCTURE, NO NESTED BLOCKS
REM ============================================
:check_python
set "CID=%~1"
set "CMM=%~2"
set "RP="

REM Step 1: Check pythonX.Y in PATH
where python%CMM% >nul 2>&1
if %errorlevel% neq 0 goto :cp2
for /f "tokens=*" %%p in ('where python%CMM% 2^>nul') do (
    set "_TEST=%%p"
)
"!_TEST!" --version 2>nul | findstr /C:"%CMM%" >nul
if %errorlevel% neq 0 goto :cp2
echo     [OK] Python %CMM% found in PATH: !_TEST!
set "FOUND_%CID%=!_TEST!"
goto :cp_done

:cp2
REM Step 2: Check py launcher
py -%CMM% --version >nul 2>&1
if %errorlevel% neq 0 goto :cp3
for /f "tokens=*" %%p in ('py -%CMM% -c "import sys; print(sys.executable)" 2^>nul') do (
    set "_TEST=%%p"
)
if not exist "!_TEST!" goto :cp3
echo     [OK] Python %CMM% found via py launcher: !_TEST!
set "FOUND_%CID%=!_TEST!"
goto :cp_done

:cp3
REM Step 3: Check common install paths
set "CVER_NO_DOT=%CMM:.=%"
set "_TEST=C:\Python%CVER_NO_DOT%\python.exe"
if exist "!_TEST!" goto :cp_found
set "_TEST=C:\Program Files\Python%CVER_NO_DOT%\python.exe"
if exist "!_TEST!" goto :cp_found
set "_TEST=C:\Program Files (x86)\Python%CVER_NO_DOT%\python.exe"
if exist "!_TEST!" goto :cp_found
set "_TEST=%LOCALAPPDATA%\Programs\Python\Python%CVER_NO_DOT%\python.exe"
if exist "!_TEST!" goto :cp_found
goto :cp4

:cp_found
echo     [OK] Python %CMM% found at: !_TEST!
set "FOUND_%CID%=!_TEST!"
goto :cp_done

:cp4
REM Step 4: Check Registry HKLM
set "RP="
reg query "HKLM\SOFTWARE\Python\PythonCore\%CMM%\InstallPath" >nul 2>&1
if %errorlevel% neq 0 goto :cp5
reg query "HKLM\SOFTWARE\Python\PythonCore\%CMM%\InstallPath" /ve > "%TEMP%\cp_reg.txt" 2>nul
for /f "tokens=2*" %%a in (%TEMP%\cp_reg.txt) do set "RP=%%b"
del "%TEMP%\cp_reg.txt" 2>nul
if not defined RP goto :cp5
if not exist "!RP!\python.exe" goto :cp5
echo     [OK] Python %CMM% found via Registry: !RP!\python.exe
set "FOUND_%CID%=!RP!\python.exe"
goto :cp_done

:cp5
REM Step 5: Check Registry HKCU
set "RP="
reg query "HKCU\SOFTWARE\Python\PythonCore\%CMM%\InstallPath" >nul 2>&1
if %errorlevel% neq 0 goto :cp6
reg query "HKCU\SOFTWARE\Python\PythonCore\%CMM%\InstallPath" /ve > "%TEMP%\cp_reg.txt" 2>nul
for /f "tokens=2*" %%a in (%TEMP%\cp_reg.txt) do set "RP=%%b"
del "%TEMP%\cp_reg.txt" 2>nul
if not defined RP goto :cp6
if not exist "!RP!\python.exe" goto :cp6
echo     [OK] Python %CMM% found via Registry: !RP!\python.exe
set "FOUND_%CID%=!RP!\python.exe"
goto :cp_done

:cp6
REM Step 6: Check Registry WOW6432Node
set "RP="
reg query "HKLM\SOFTWARE\WOW6432Node\Python\PythonCore\%CMM%\InstallPath" >nul 2>&1
if %errorlevel% neq 0 goto :cp_notfound
reg query "HKLM\SOFTWARE\WOW6432Node\Python\PythonCore\%CMM%\InstallPath" /ve > "%TEMP%\cp_reg.txt" 2>nul
for /f "tokens=2*" %%a in (%TEMP%\cp_reg.txt) do set "RP=%%b"
del "%TEMP%\cp_reg.txt" 2>nul
if not defined RP goto :cp_notfound
if not exist "!RP!\python.exe" goto :cp_notfound
echo     [OK] Python %CMM% found via Registry (WOW64): !RP!\python.exe
set "FOUND_%CID%=!RP!\python.exe"
goto :cp_done

:cp_notfound
echo     [--] Python %CMM% not found

:cp_done
exit /b 0

:end_error
echo.
echo ============================================================
echo   [ERROR] Setup Failed
echo ============================================================
echo.
echo   Possible solutions:
echo.
echo   1. Download Python manually:
echo      https://www.python.org/downloads/
echo.
echo   2. Check "Add Python to PATH" during install.
echo.
echo   3. Right-click this file then Run as Administrator.
echo.
echo   4. Check your internet connection.
echo.
pause
exit /b 1


:do_cd
if not "%~1"=="" (
    if exist "%~1" (
        cd /d "%~1"
        echo.
        echo ============================================================
        echo   [OK] Switched working directory to: %CD%
        echo ============================================================
        echo.
    )
)
exit /b 0
