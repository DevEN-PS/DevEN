@echo off
setlocal enabledelayedexpansion

echo ============================================
echo DevEN - Requirements Updater
echo ============================================
echo.

:: Find virtual environment
set "VENV_FOUND="
for /d %%d in ("venv_*") do (
    set "VENV_FOUND=%%d"
    set "VENV_NAME=%%~nxd"
)

if not defined VENV_FOUND (
    echo [ERROR] No virtual environment found!
    echo Make sure you're in a DevEN folder.
    pause
    exit /b 1
)

echo Virtual Environment: !VENV_NAME!
echo.

:: Update requirements
echo Installing/updating requirements...
echo.

call "!VENV_FOUND!\Scripts\activate.bat"
pip install -r requirements.txt --upgrade

echo.
echo ============================================
echo Update Complete!
echo ============================================
pause
exit /b 0