@echo off
setlocal enabledelayedexpansion
title DevEN Auto Setup Launcher

for /f "tokens=2 delims= " %%v in ('python --version 2^>nul') do set PY_VER=%%v
for /f "tokens=1,2 delims=." %%a in ("!PY_VER!") do (
    set MAJ=%%a
    set MIN=%%b
)

set TARGET_FOLDER=DevEN_V2_Py!MAJ!!MIN!
if exist "!TARGET_FOLDER!" (
    cd /d "!TARGET_FOLDER!"
    if exist setup_DevEN.bat (
        call setup_DevEN.bat
    ) else (
        python app.pyc
    )
) else (
    echo Version folder !TARGET_FOLDER! not found. Launching first available build...
    for /d %%d in (DevEN_V2_Py*) do (
        cd /d "%%d"
        python app.pyc
        exit /b
    )
)
